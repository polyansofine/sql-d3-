export { default } from "./FuseMessage";

export const apiUrl = "http://123.206.118.90:5000/api/";
// export const apiUrl = "http://localhost:5000/api/";
